/*Pass by Value
○ Definition: Copies the value of the arguments into the function's parameters.
○ Task: Create a function that modifies a parameter passed by value and observe
the changes.*/

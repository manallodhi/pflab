/*Arguments
○ Definition: Actual values passed to the function parameters.
○ Task: Call a function with different argument values and print the results.*/
